# -*- coding: utf-8 -*-

import global_var
import contingency_test
import input_arg
import input_validation
import significance_corr