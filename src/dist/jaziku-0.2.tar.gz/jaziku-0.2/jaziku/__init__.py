import jaziku
