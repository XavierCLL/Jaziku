#!/bin/bash

DIRTOINSTALL="/usr/local"

if [[ $(/usr/bin/id -u) -ne 0 ]]; then
    echo -e "\nNot running as root"
	echo -e "run script install.sh as root or with sudo command\n"
    exit
fi

if [ -d "$DIRTOINSTALL/jaziku" ]; then
	echo -e "delete old version of Jaziku...\n"
	rm -rf $DIRTOINSTALL/jaziku
	rm $DIRTOINSTALL/bin/jaziku
fi

cp -r jaziku $DIRTOINSTALL/

ln -s $DIRTOINSTALL/jaziku/jaziku $DIRTOINSTALL/bin/jaziku

chown root.root -R /usr/local/jaziku
chmod 755 -R /usr/local/jaziku

echo -e "install done\nnow you can run jaziku in console\n"